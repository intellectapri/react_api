/**
 * Preparing environment for tests
 */

const seed = require('./seedDatabase');

seed();